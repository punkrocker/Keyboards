SweepPluck v1.0
================
基于本仓库 Sweep High 的 34 键正交分体改版。

打开工程
  左侧：SweepPluck.kicad_pro
  右侧：SweepPluck-right.kicad_pro
  使用 KiCad 10；每侧配套现代原理图、PCB 和本地封装/符号库。
  原理图是完整的引脚连接图，使用被动引脚符号表示实际焊盘连接。
  ERC 检查连接完整性，不检查 MCU 引脚的电气方向和供电类型。

配列与结构
  左右各 17 键：3 行 x 5 列主键，内侧底部 2 个水平拇指键。
  所有键位旋转角为 0；横向、纵向中心距均为 19.05 mm。
  两侧 PCB 分别为 116.6 x 92 mm，2 层，厚度 1.6 mm。
  支持 Sweep High 原通用焊接封装的 Choc V2 / Choc V1 / MX / Alps。
  无热插拔。轴体电气焊盘和 4.9 mm 中心孔保留原设计。
  原重叠的 1.7 / 1.8 mm 侧定位孔合并为 2.17 x 1.8 mm NPTH 长圆孔，
  中心位于轴心两侧 +/-5.315 mm；新孔完整包含两个原始圆孔。
  新增每侧 2 个 3.2 mm 外侧底部安装孔，替代原 tenting puck。
  左右板没有拼板桥接，分别加工；PCB 不可正反共用。

电路
  保留 17 键直连方式、Pro Micro 接口、TRRS、复位按钮和电池电源开关。
  保留原开关至 MCU 的 GPIO 对应关系；重新布线。
  纠正原板的重复器件和跨侧电源开关命名/放置问题。
  不需要矩阵二极管。采用铜线连接 GND，没有依靠未验证的填充区连接。
  MCU 及键开关编号/网络详见每侧的 *-pins.csv。
  本次未新增或烧录 QMK/ZMK 固件；实际键码需在现有 Sweep 固件中配置。

文件
  SweepPluck-preview.png：两侧实际 PCB 正面配列预览。
  *-preview.svg：矢量 PCB 预览。
  *-plate.kicad_pcb：两侧定位板，14 x 14 mm 轴孔、控制器避让口及安装孔。
  plate-left.dxf / plate-right.dxf：毫米单位定位板切割轮廓。
  gerbers/SweepPluck/：左侧铜层、阻焊、丝印、板框、PTH/NPTH 钻孔。
  gerbers/SweepPluck-right/：对应右侧加工文件。
  SweepPluck-left-gerbers.zip / SweepPluck-right-gerbers.zip：加工文件压缩包。
  verification/：最终 DRC、ERC、导出网表及连接核对摘要。
  tools/：生成与核对脚本。

验证
  KiCad 10.0.3：两侧 PCB 的完整 DRC 均为 0 违规、0 未连接。
  两侧定位板 DRC 均为 0 违规；两侧原理图 ERC 均为 0 违规。
  每侧 68 个有效焊盘/网络对应关系与原理图导出的网表完全相符。
  PCB 规则：线宽 >=0.20 mm，电气间距 >=0.20 mm，铜到板边 >=0.25 mm，
  默认走线 0.25 mm，默认过孔 0.60 / 0.30 mm。
  尚未实物打样；轴体、键帽、控制器及定位板厚度的机械装配需样板确认。

重新生成
  从仓库根目录用 KiCad 自带 Python 执行 tools/build.py，会覆盖 PCB 为未布线版。
  使用 Freerouting 2.1.0 导入 verification/*.dsn，输出同名 *.ses：
    java -Djava.awt.headless=true -jar freerouting-2.1.0.jar -de board.dsn -do board.ses -mp 8 -mt 1
  在 KiCad 导入对应 SES 后保存，再执行 tools/finish.py、tools/plate.py。
  重新导出网表和 DRC 报告后，tools/verify.py 核对原理图与 PCB 的引脚网络。
  Freerouting 官方说明：https://github.com/freerouting/freerouting/blob/master/docs/command_line_arguments.md
  当前交付 PCB 已完成布线，直接打开即可，无需重新运行生成脚本。

授权沿用仓库 LICENSE，副本见本目录 LICENSE。

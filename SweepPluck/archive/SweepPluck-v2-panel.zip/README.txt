SweepPluck v2.0 — 单工程、紧凑正交分体拼板
=========================================

直接打开 SweepPluck.kicad_pro。
与 Sweep High 一样，左右两侧位于同一份 PCB 和同一份原理图中。
不再使用左右独立工程；上一版完整保存在 archive/SweepPluck-v1-split.zip。

尺寸与布局
  34 键：每侧 3×5 主键，加内侧第四排 2 个水平拇指键。
  所有键位旋转角为 0；横纵键距均为 19.05 mm。
  每侧 PCB：95.25×77.0 mm。
  上一版每侧为 116.6×92.0 mm，本次 PCB 面积减少 31.63%。
  整张拼板：194.5×77.0 mm，左右间距 4 mm。
  尺寸为 PCB 板框，不包括向外伸出的 USB/TRRS 接口。
  主控横放在第四排外侧三个空键位下，左侧旋转 +90°，右侧 -90°。
  USB 分别朝左右外缘；TRRS 朝下；复位、电源开关、电池焊点紧凑放在旁边。
  主控摆放以原 ProMicro_v3_min 封装的 33.2×17.95 mm 模块外形为依据。

拼板与定位板
  PCB 为 2 层 FR-4，厚度 1.6 mm。
  左右使用两个 4×2.5 mm 可折断连接桥拼在一起。
  每个桥的两个断点各有 3 个 0.5 mm 孔，孔距 0.75 mm，共 12 个鼠咬孔。
  连接桥只作机械连接，没有跨桥铜线；折开后由 TRRS 线连接左右电路。
  两侧独立网络名称含 _L/_R，避免拼板检查要求左右铜线互连。
  左右不可正反共用，控制器的旋转方向不同。
  SweepPluck-plate.kicad_pcb / SweepPluck-plate.dxf 同时包含两侧定位板。
  定位板保留 14×14 mm 轴孔，并避让底部主控及其他器件。
  每侧两个 3.2 mm 安装孔移到主键网格交点，避免为安装孔增加外边框。
  安装孔处的固定件需低于键帽活动空间，采用平头或沉头方案。

轴体与电路
  保留 Sweep High 的 Choc V2 / Choc V1 / MX / Alps 通用焊接封装；无热插拔。
  原重叠的侧定位圆孔沿用上一版合并后的 2.17×1.8 mm NPTH 长圆孔，
  中心位于轴心两侧 +/-5.315 mm，包含原 1.7/1.8 mm 孔；中心孔为 4.9 mm。
  保留每侧 17 键直连、电池开关、TRRS、复位及 Pro Micro 接口。
  GPIO 和连接器的有效引脚映射与上一版逐项核对，136 个连接全部保留。
  不需要矩阵二极管。本次未新增或烧录 QMK/ZMK 固件。
  预览中的数字是原 Switch1–Switch17 网络编号，不是实际键码。
  电气网络 _L/_R 名称变化只为拼板检查；MCU 引脚对应关系未变。

交付文件
  SweepPluck.kicad_pro / .kicad_pcb / .kicad_sch：唯一主工程。
  SweepPluck.kicad_sym、SweepPluck.pretty、库表：本地符号和封装。
  SweepPluck-preview.png / SweepPluck-layout.svg：实际位置生成的布局示意。
  SweepPluck-preview.svg：已布线 PCB 的矢量预览。
  SweepPluck-plate.kicad_pcb / SweepPluck-plate.dxf：组合定位板及毫米切割轮廓。
  SweepPluck-pins.csv：全部器件的焊盘、网络和坐标。
  gerbers/、SweepPluck-gerbers.zip：整张拼板的铜层、阻焊、丝印、板框、PTH/NPTH 钻孔。
  verification/：最终 DRC、原理图一致性、ERC、导出网表与核对摘要。

验证与限制
  KiCad 10.0.3：PCB 完整 DRC 0 违规、0 未连接、0 原理图一致性问题。
  原理图 ERC 0 违规；定位板 DRC 0 违规。
  确认没有铜线穿过折断连接桥；34 个键位数量及方向核对通过。
  DRC 限制：线宽 >=0.20 mm、电气间距 >=0.20 mm、铜到板边/钻孔 >=0.25 mm。
  走线采用 0.25 mm 宽及 0.30 mm 路由间距，过孔为 0.60/0.30 mm。
  原理图采用被动引脚连接图；ERC 不验证 MCU 供电类型或 GPIO 输入输出方向。
  尚未实物打样，需按实物主控、轴体、键帽及定位板厚度确认机械装配和接口空间。

重新生成（当前交付已完成，无需运行）
  从仓库根目录使用 KiCad 自带 Python：
    python SweepPluck/tools/compact.py build
  上一步从 archive 中的 v1 封装重建单工程，并覆盖 PCB 为未布线版。
  使用 Freerouting 2.1.0 生成同名会话：
    java -Djava.awt.headless=true -jar freerouting-2.1.0.jar -de SweepPluck/verification/SweepPluck.dsn -do SweepPluck/verification/SweepPluck.ses -mp 8 -mt 1
    python SweepPluck/tools/compact.py import
  导出完整 DRC。如果仅有 track_dangling 警告且没有未连接项：
    python SweepPluck/tools/compact.py prune
  重新执行 DRC，直到冗余支线清理完成；脚本不会忽略或屏蔽任何违规项。
  最终导出 verification/SweepPluck.xml、drc-SweepPluck.json、
  drc-SweepPluck-plate.json、erc-SweepPluck.json 后：
    python SweepPluck/tools/compact.py verify
    python SweepPluck/tools/preview.py
  Freerouting 官方说明：https://github.com/freerouting/freerouting/blob/master/docs/command_line_arguments.md

授权沿用本仓库 LICENSE。

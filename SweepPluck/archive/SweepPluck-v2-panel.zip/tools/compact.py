"""SweepPluck v2: one project, compact two-half mouse-bite panel.

With KiCad Python, run from any directory:
  compact.py build       generate placement and DSN from archived v1 footprints
  compact.py import      import verification/SweepPluck.ses, finish project/plate
  compact.py verify     compare schematic XML with PCB and final reports
"""
from pathlib import Path
from zipfile import ZipFile
import pcbnew as p
import json, re, uuid, csv, sys, xml.etree.ElementTree as ET

D=Path(__file__).resolve().parents[1]
V=D/'verification'
L,R=35.475,229.975
IL,IR=130.725,134.725
TOP,BOTTOM=50.475,127.475
MIRROR=265.45
COMMON={'gnd':'GND','vcc':'VCC','raw':'RAW','reset':'RESET','reset_r':'RESET','BT+':'BAT','BT+_r':'BAT','Switch18':'SERIAL','Switch18_r':'SERIAL'}

def xy(x,y): return p.VECTOR2I(p.FromMM(x),p.FromMM(y))
def q(s): return json.dumps(str(s),ensure_ascii=False)
def uid(): return str(uuid.uuid4())
def chunks(s):
    depth=0; quoted=False; escaped=False; start=0; out=[]
    for i,c in enumerate(s):
        if quoted:
            if escaped: escaped=False
            elif c=='\\': escaped=True
            elif c=='"': quoted=False
            continue
        if c=='"': quoted=True
        elif c=='(':
            depth+=1
            if depth==2: start=i
        elif c==')':
            if depth==2: out.append(s[start:i+1])
            depth-=1
    return out

def polygon(b,points):
    for i,a in enumerate(points):
        s=p.PCB_SHAPE(); s.SetShape(p.SHAPE_T_SEGMENT); s.SetStart(xy(*a)); s.SetEnd(xy(*points[(i+1)%len(points)])); s.SetLayer(p.Edge_Cuts); s.SetWidth(p.FromMM(.05)); b.Add(s)
def rect(b,x1,y1,x2,y2): polygon(b,[(x1,y1),(x2,y1),(x2,y2),(x1,y2)])
def label(b,text,x,y,layer=p.F_SilkS,size=.8):
    t=p.PCB_TEXT(b); t.SetText(text); t.SetPosition(xy(x,y)); t.SetTextSize(xy(size,size)); t.SetTextThickness(p.FromMM(.12)); t.SetLayer(layer); b.Add(t)

def save_project():
    rules={'min_clearance':.2,'min_copper_edge_clearance':.25,'min_track_width':.2,'min_via_diameter':.6,'min_through_hole_diameter':.3,'min_hole_to_hole':.25}
    project={'meta':{'filename':'SweepPluck.kicad_pro','version':1},'board':{'design_settings':{'rules':rules}},'net_settings':{'classes':[{'name':'Default','clearance':.2,'track_width':.25,'via_diameter':.6,'via_drill':.3}],'version':3}}
    (D/'SweepPluck.kicad_pro').write_text(json.dumps(project,indent=2),encoding='utf-8')

def build():
    V.mkdir(exist_ok=True)
    with ZipFile(D/'archive'/'SweepPluck-v1-split.zip') as z:
        sources=[z.read(n+'.kicad_pcb').decode('utf-8') for n in ['SweepPluck','SweepPluck-right']]
    footprints=[]; nets={}; header=[]
    for side,s in enumerate(sources):
        parts=chunks(s)
        if side==0: header=[c for c in parts if c[1:].split()[0] in ['version','generator','generator_version','general','paper','layers','setup']]
        fs=[c for c in parts if c.startswith('(footprint ')]
        def newnet(m):
            name=m.group(2)
            if not name: return '(net 0 "")'
            if name in COMMON: name=COMMON[name]+('_R' if side else '_L')
            if name not in nets: nets[name]=len(nets)+1
            return f'(net {nets[name]} {q(name)})'
        footprints += [re.sub(r'\(net (?:(\d+) )?"([^"\n]*)"\)',newnet,f) for f in fs]
    raw='(kicad_pcb\n'+'\n'.join(header)+'\n(net 0 "")\n'+'\n'.join(f'(net {n} {q(name)})' for name,n in nets.items())+'\n'+'\n'.join(footprints)+'\n)'
    inputfile=V/'placement-source.kicad_pcb'; inputfile.write_text(raw,encoding='utf-8')
    save_project(); b=p.LoadBoard(str(inputfile)); b.SetFileName(str(D/'SweepPluck.kicad_pcb'))
    locations={'U1':(54.5,117.7,90),'U2':(210.95,117.7,-90),'J1':(89,126,180),'J2':(176.45,126,180),
        'SW_POWER1':(78.5,112,180),'SW_POWERR1':(186.95,112,0),'RSW1':(78.5,122,0),'RSW2':(186.95,122,180),
        'BATP1':(72,111,0),'BATG1':(72,124,0),'BATP2':(193.45,111,0),'BATG2':(193.45,124,0),
        'H1':(54.525,69.525,0),'H2':(111.675,88.575,0),'H3':(210.925,69.525,0),'H4':(153.775,88.575,0)}
    for f in b.GetFootprints():
        ref=f.GetReference()
        if ref in locations:
            x,y,a=locations[ref]; f.SetOrientationDegrees(a); f.SetPosition(xy(x,y))
        elif 'keyswitch_' in str(f.GetFPID().GetLibItemName()) and ref.endswith('_r1'):
            f.SetPosition(f.GetPosition()+xy(-35.15,0))
        if ref.startswith('H'): f.SetAttributes(f.GetAttributes() | p.FP_BOARD_ONLY)
        if 'SPDT' in str(f.GetFPID().GetLibItemName()):
            for pad in f.Pads():
                if pad.GetNumber()=='0': pad.SetNumber('')
                elif pad.GetNumber()=='1':
                    name=f'unconnected-({ref}-Pad1)'; net=p.NETINFO_ITEM(b,name); b.Add(net); pad.SetNetCode(net.GetNetCode())
    # Connected mechanical panel with two 4 x 2.5 mm breakaway bridges.
    polygon(b,[(L,TOP),(IL,TOP),(IL,78.75),(IR,78.75),(IR,TOP),(R,TOP),(R,BOTTOM),(IR,BOTTOM),(IR,97.25),(IL,97.25),(IL,BOTTOM),(L,BOTTOM)])
    rect(b,IL,81.25,IR,94.75)
    for i,(x,y) in enumerate([(IL+.6,80),(IR-.6,80),(IL+.6,96),(IR-.6,96)],1):
        f=p.FOOTPRINT(b); f.SetReference('MB'+str(i)); f.SetValue('Mousebite_3x0.5_P0.75'); f.SetPosition(xy(x,y)); f.SetFPID(p.LIB_ID('SweepPluck','Mousebite_3x0.5_P0.75')); f.SetAttributes(p.FP_BOARD_ONLY | p.FP_EXCLUDE_FROM_BOM | p.FP_EXCLUDE_FROM_POS_FILES)
        for dy in [-.75,0,.75]:
            pad=p.PAD(f); pad.SetAttribute(p.PAD_ATTRIB_NPTH); pad.SetShape(p.PAD_SHAPE_CIRCLE); pad.SetSize(xy(.5,.5)); pad.SetDrillSize(xy(.5,.5)); pad.SetFPRelativePosition(xy(0,dy)); pad.SetPosition(xy(x,y+dy)); pad.SetLayerSet(p.LSET.AllCuMask()); f.Add(pad)
        f.Reference().SetVisible(False); f.Value().SetVisible(False); b.Add(f)
    label(b,'SweepPluck L v2',82,125.5,size=.8); label(b,'SweepPluck R v2',183.45,125.5,size=.8)
    for x in [132.3,135.1]:
        label(b,'BREAK',x,87.4,layer=p.Dwgs_User,size=.6)
    # Export with real project routing limits, rather than temporary board defaults.
    ds=b.GetDesignSettings(); ds.m_MinClearance=p.FromMM(.2); ds.m_CopperEdgeClearance=p.FromMM(.25); ds.m_TrackMinWidth=p.FromMM(.2); ds.m_HoleClearance=p.FromMM(.25)
    p.SaveBoard(str(D/'SweepPluck.kicad_pcb'),b)
    assert p.ExportSpecctraDSN(b,str(V/'SweepPluck.dsn'))
    dsn=V/'SweepPluck.dsn'
    # Specctra only exports the generic net clearance. Route at 0.30 mm,
    # providing margin for KiCad's separate 0.25 mm drill/edge constraints.
    text=dsn.read_text(); text=re.sub(r'\(clearance (?:200|50)\b','(clearance 300',text); text=text.replace('(width 200)','(width 250)'); dsn.write_text(text)
    finish(b)
    print('Compact placement: 34 switches, one 194.5 x 77 mm panel')

def schematic(b):
    root=uid(); libs=[]; instances=[]; annotations=[]
    fs=[f for f in b.GetFootprints() if not f.GetAttributes() & p.FP_BOARD_ONLY]
    fs.sort(key=lambda f:(f.GetReference()=='U1' or f.GetReference()=='U2', f.GetReference()))
    side_lists=[[],[]]
    for f in fs: side_lists[int(p.ToMM(f.GetPosition().x)>133.7)].append(f)
    i=0
    for side,items in enumerate(side_lists):
        for j,f in enumerate(items):
            symbol='SweepPluck:P'+str(i); pads={z.GetNumber():z.GetNetname() for z in f.Pads() if z.GetNumber() and z.GetAttribute()!=p.PAD_ATTRIB_NPTH}
            x=30.48+(j%5)*76.2; y=25.4+(j//5)*35.56+side*203.2
            if f.GetReference().startswith('U'): x,y=431.8,25.4+side*203.2
            n=len(pads); h=(n+1)*2.54; ref=f.GetReference(); val=f.GetValue(); fp='SweepPluck:'+str(f.GetFPID().GetLibItemName())
            fx='(effects (font (size 1 1)))'; small='(effects (font (size .8 .8)))'
            props=f'(property "Reference" {q(ref)} (at 0 3 0) {fx}) (property "Value" {q(val)} (at 0 0 0) {fx}) (property "Footprint" {q(fp)} (at 0 0 0) {fx} (hide yes))'
            pins=' '.join(f'(pin passive line (at -11.43 {-2.54*(k+1):.4f} 0) (length 5.08) (name {q(num)} {small}) (number {q(num)} {small}))' for k,num in enumerate(pads))
            libs.append(f'(symbol {q(symbol)} (pin_names (offset 0)) (in_bom yes) (on_board yes) {props} (symbol "P{i}_0_1" (rectangle (start -6.35 0) (end 6.35 {-h:.4f}) (stroke (width .254) (type default)) (fill (type background)))) (symbol "P{i}_1_1" {pins}))')
            instance=uid(); f.SetPath(p.KIID_PATH('/'+root+'/'+instance))
            iprops=f'(property "Reference" {q(ref)} (at {x} {y-3} 0) {fx}) (property "Value" {q(val)} (at {x} {y} 0) {fx}) (property "Footprint" {q(fp)} (at {x} {y} 0) {fx} (hide yes))'
            instances.append(f'(symbol (lib_id {q(symbol)}) (at {x} {y} 0) (unit 1) (in_bom yes) (on_board yes) (dnp no) (uuid {instance}) {iprops} '+ ' '.join(f'(pin {q(num)} (uuid {uid()}))' for num in pads)+f' (instances (project "SweepPluck" (path "/{root}" (reference {q(ref)}) (unit 1)))))')
            for k,(num,net) in enumerate(pads.items()):
                xx=x-11.43; yy=y+(k+1)*2.54
                if net and not net.startswith('unconnected-'): annotations.append(f'(global_label {q(net)} (shape passive) (at {xx:.4f} {yy:.4f} 0) {small} (uuid {uid()}))')
                else: annotations.append(f'(no_connect (at {xx:.4f} {yy:.4f}) (uuid {uid()}))')
            i+=1
        caption='RIGHT' if side else 'LEFT'
        annotations.append(f'(text "{caption} HALF - 17 direct GPIO keys" (at 25.4 {12.7+side*203.2} 0) (effects (font (size 2 2)) (justify left)) (uuid {uid()}))')
    note='TRRS cable connects J1/J2 externally: SERIAL_L-SERIAL_R, VCC_L-VCC_R, GND_L-GND_R.\nPanel bridges are mechanical only; no copper crosses between halves.'
    annotations.append(f'(text {q(note)} (at 420 120 0) (effects (font (size 1 1)) (justify left)) (uuid {uid()}))')
    result=f'(kicad_sch (version 20250114) (generator "eeschema") (uuid {root}) (paper "A2") (title_block (title "SweepPluck compact 34-key panel") (rev "2.0")) (lib_symbols '+ '\n'.join(libs)+')\n'+'\n'.join(annotations+instances)+' (sheet_instances (path "/" (page "1"))))\n'
    (D/'SweepPluck.kicad_sch').write_text(result,encoding='utf-8')
    library='\n'.join(s.replace('(symbol "SweepPluck:', '(symbol "',1) for s in libs)
    (D/'SweepPluck.kicad_sym').write_text('(kicad_symbol_lib (version 20241209) (generator "kicad_symbol_editor")\n'+library+'\n)',encoding='utf-8')
    (D/'sym-lib-table').write_text('(sym_lib_table (version 7) (lib (name "SweepPluck")(type "KiCad")(uri "${KIPRJMOD}/SweepPluck.kicad_sym")(options "")(descr "Combined pin wiring symbols")))\n',encoding='utf-8')

def plate(b):
    out=p.BOARD()
    polygon(out,[(L,TOP),(IL,TOP),(IL,BOTTOM),(93,BOTTOM),(93,108),(L,108)])
    polygon(out,[(IR,TOP),(R,TOP),(R,108),(MIRROR-93,108),(MIRROR-93,BOTTOM),(IR,BOTTOM)])
    for f in b.GetFootprints():
        x=p.ToMM(f.GetPosition().x); y=p.ToMM(f.GetPosition().y)
        if 'keyswitch_' in str(f.GetFPID().GetLibItemName()): rect(out,x-7,y-7,x+7,y+7)
        elif f.GetReference().startswith('H'):
            c=p.PCB_SHAPE(); c.SetShape(p.SHAPE_T_CIRCLE); c.SetCenter(xy(x,y)); c.SetEnd(xy(x+1.6,y)); c.SetLayer(p.Edge_Cuts); c.SetWidth(p.FromMM(.05)); out.Add(c)
    p.SaveBoard(str(D/'SweepPluck-plate.kicad_pcb'),out)

def finish(b):
    ds=b.GetDesignSettings(); ds.m_MinClearance=p.FromMM(.2); ds.m_CopperEdgeClearance=p.FromMM(.25); ds.m_TrackMinWidth=p.FromMM(.2); ds.m_HoleClearance=p.FromMM(.25)
    schematic(b); plate(b)
    p.SaveBoard(str(D/'SweepPluck.kicad_pcb'),b)
    libdir=D/'SweepPluck.pretty'
    for f in b.GetFootprints(): p.PCB_IO_MGR.FindPlugin(p.PCB_IO_MGR.KICAD_SEXP).FootprintSave(str(libdir),f)
    with (D/'SweepPluck-pins.csv').open('w',newline='',encoding='utf-8-sig') as stream:
        w=csv.writer(stream); w.writerow(['reference','pad','net','x_mm','y_mm'])
        for f in sorted(b.GetFootprints(),key=lambda f:f.GetReference()):
            for z in f.Pads():
                if z.GetNumber(): w.writerow([f.GetReference(),z.GetNumber(),z.GetNetname(),p.ToMM(z.GetPosition().x),p.ToMM(z.GetPosition().y)])
    save_project()

def verify():
    b=p.LoadBoard(str(D/'SweepPluck.kicad_pcb')); tree=ET.parse(V/'SweepPluck.xml')
    sch={(z.get('ref'),z.get('pin')):net.get('name').lstrip('/') for net in tree.findall('.//nets/net') for z in net.findall('node') if not net.get('name').startswith('unconnected-')}
    pcb={(f.GetReference(),z.GetNumber()):z.GetNetname() for f in b.GetFootprints() for z in f.Pads() if z.GetNumber() and z.GetNetname() and not z.GetNetname().startswith('unconnected-')}
    assert sch==pcb,(sch.items()-pcb.items(),pcb.items()-sch.items())
    original={}
    with ZipFile(D/'archive'/'SweepPluck-v1-split.zip') as z:
        for side,name in enumerate(['SweepPluck','SweepPluck-right']):
            temp=V/(name+'-gpio-source.kicad_pcb'); temp.write_bytes(z.read(name+'.kicad_pcb')); old=p.LoadBoard(str(temp))
            for f in old.GetFootprints():
                for pad in f.Pads():
                    if pad.GetNumber() and pad.GetNetname():
                        net=pad.GetNetname(); net=COMMON[net]+('_R' if side else '_L') if net in COMMON else net
                        original[(f.GetReference(),pad.GetNumber())]=net
            temp.unlink()
    assert original==pcb,'A functional GPIO, power, or connector mapping changed'
    refs=[f.GetReference() for f in b.GetFootprints()]; assert len(refs)==len(set(refs))
    keys=[f for f in b.GetFootprints() if 'keyswitch_' in str(f.GetFPID().GetLibItemName())]; assert len(keys)==34
    assert all(f.GetOrientationDegrees()==0 for f in keys)
    for track in b.GetTracks():
        right=track.GetNetname().endswith(('_R','_r'))
        for pt in [track.GetStart(),track.GetEnd()]:
            assert p.ToMM(pt.x)>=IR+.25 if right else p.ToMM(pt.x)<=IL-.25,'Copper crosses a breakaway bridge'
    paths={f.GetReference():f.GetPath().AsString() for f in b.GetFootprints() if not f.GetAttributes() & p.FP_BOARD_ONLY}; assert all(v.count('/')==2 for v in paths.values())
    result={'project':'SweepPluck','revision':'2.0','panel_mm':[194.5,77],'half_mm':[95.25,77],'previous_half_mm':[116.6,92],'half_area_reduction_percent':round((1-95.25*77/(116.6*92))*100,2),'keys':34,'matching_pin_net_assignments':len(pcb),'schematic_matches_pcb':True,'gpio_and_connector_mapping_preserved':True,'copper_crosses_bridges':False,'mouse_bite_holes':12,'traces':len(list(b.GetTracks()))}
    for name in ['drc-SweepPluck','drc-SweepPluck-plate']:
        report=json.loads((V/(name+'.json')).read_text()); assert not report['violations'] and not report['unconnected_items'],name
        if name=='drc-SweepPluck': assert not report['schematic_parity']; result['schematic_parity_issues']=0
        result[name]={'violations':0,'unconnected_items':0}
    erc=json.loads((V/'erc-SweepPluck.json').read_text()); assert all(not s['violations'] for s in erc['sheets']); result['erc_violations']=0
    (V/'summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8'); print(json.dumps(result,indent=2))

def prune():
    # Delete only redundant free-ended tracks reported by KiCad; do not mask checks.
    report=json.loads((V/'drc-SweepPluck.json').read_text())
    assert not report['unconnected_items']
    assert all(v['type']=='track_dangling' for v in report['violations'])
    ids={item['uuid'] for v in report['violations'] for item in v['items']}
    path=D/'SweepPluck.kicad_pcb'; text=path.read_text(encoding='utf-8'); parts=chunks(text)
    kept=[c for c in parts if not (c.startswith('(segment ') or c.startswith('(segment\n') or c.startswith('(via ')) or not any(s in c for s in ids)]
    removed=len(parts)-len(kept); assert removed==len(ids),(removed,len(ids))
    path.write_text('(kicad_pcb\n'+'\n'.join(kept)+'\n)',encoding='utf-8'); print('Removed',removed,'redundant track segments')

if __name__=='__main__':
    mode=sys.argv[1] if len(sys.argv)>1 else 'build'
    if mode=='build': build()
    elif mode=='import':
        b=p.LoadBoard(str(D/'SweepPluck.kicad_pcb')); assert p.ImportSpecctraSES(b,str(V/'SweepPluck.ses')); finish(b)
    elif mode=='verify': verify()
    elif mode=='prune': prune()
    else: raise SystemExit('Use build, import, or verify')


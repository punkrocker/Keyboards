"""Generate an assembly/layout SVG from the final PCB's component positions."""
from pathlib import Path
import pcbnew as p
import html, re
from compact import D, L, R, IL, IR, TOP, BOTTOM, MIRROR

b=p.LoadBoard(str(D/'SweepPluck.kicad_pcb'))
s=['<svg xmlns="http://www.w3.org/2000/svg" width="207mm" height="97mm" viewBox="30 39 207 97">',
   '<rect x="30" y="39" width="207" height="97" fill="#f2f4f7"/>',
   '<style>text{font-family:Arial,sans-serif;fill:#24334a;text-anchor:middle} .small{font-size:1.4px}</style>',
   '<text x="133.5" y="44" font-size="2.5">SweepPluck v2 — 34-key ortholinear split</text>']
outer=[(L,TOP),(IL,TOP),(IL,78.75),(IR,78.75),(IR,TOP),(R,TOP),(R,BOTTOM),(IR,BOTTOM),(IR,97.25),(IL,97.25),(IL,BOTTOM),(L,BOTTOM)]
inner=[(IL,81.25),(IR,81.25),(IR,94.75),(IL,94.75)]
def path(points): return 'M '+' L '.join(f'{x},{y}' for x,y in points)+' Z'
s.append(f'<path d="{path(outer)} {path(inner)}" fill="#315b55" stroke="#24473f" stroke-width=".2" fill-rule="evenodd"/>')
def rect(x,y,w,h,fill,stroke='#70818a',r=0): s.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width=".15"/>')
def text(x,y,string,size=1.6,color='#24334a'): s.append(f'<text x="{x}" y="{y}" font-size="{size}" style="fill:{color}">{html.escape(string)}</text>')
for f in b.GetFootprints():
    ref=f.GetReference(); x=p.ToMM(f.GetPosition().x); y=p.ToMM(f.GetPosition().y); fid=str(f.GetFPID().GetLibItemName())
    if 'keyswitch_' in fid:
        rect(x-9,y-9,18,18,'#f7f5ee',r=1.2)
        num=next((re.search(r'Switch(\d+)',pad.GetNetname()).group(1) for pad in f.Pads() if re.search(r'Switch(\d+)',pad.GetNetname())),ref)
        text(x,y+1,num,2.5)
    elif ref.startswith('U'):
        left=ref=='U1'; bx=x-18.375 if left else x-14.825
        rect(bx,y-8.975,33.2,17.95,'#223b61',r=.4)
        ux=x-21.275 if left else x+18.225
        rect(ux,y-3.825,3.05,7.65,'#bbc5cb',r=.2)
        text(x-.8 if left else x+.8,y+.6,'Pro Micro',2,'#ffffff')
        text(x-.8 if left else x+.8,y+3.5,'USB ←' if left else 'USB →',1.8,'#c7d8ed')
        for pad in f.Pads():
            px=p.ToMM(pad.GetPosition().x); py=p.ToMM(pad.GetPosition().y)
            s.append(f'<circle cx="{px}" cy="{py}" r=".65" fill="#e9c76e"/>')
    elif ref.startswith('J'):
        rect(x-3.125,y-12.32,6.255,14.395,'#3d4150',r=.4)
        text(x,y-5,'TRRS',1.4,'#fff')
    elif ref.startswith('RSW'):
        rect(x-1.7,y-1.4,3.4,2.8,'#d2d9dd',r=.2); text(x,y+3.6,'RESET',1.2,'#fff')
    elif ref.startswith('SW_POWER') or ref=='SW_POWERR1':
        rect(x-4.15,y-2.2,8.3,4.4,'#d2d9dd',r=.2); text(x,y+.5,'PWR',1.4)
    elif ref.startswith('BAT'):
        s.append(f'<circle cx="{x}" cy="{y}" r="1.05" fill="#e9c76e"/>'); text(x,y+.5,'+' if 'BATP' in ref else '−',1.6)
    elif ref.startswith('H'):
        s.append(f'<circle cx="{x}" cy="{y}" r="1.6" fill="#f2f4f7" stroke="#24473f" stroke-width=".15"/>')
    elif ref.startswith('MB'):
        for pad in f.Pads(): s.append(f'<circle cx="{p.ToMM(pad.GetPosition().x)}" cy="{p.ToMM(pad.GetPosition().y)}" r=".25" fill="#f2f4f7"/>')
text((IL+IR)/2,89,'SNAP',1.2,'#70818a')
text((L+IL)/2,133.5,'95.25 × 77 mm',2)
text((IR+R)/2,133.5,'95.25 × 77 mm',2)
s.append('</svg>')
(D/'SweepPluck-layout.svg').write_text('\n'.join(s),encoding='utf-8')
print('Assembly SVG generated from final PCB')
